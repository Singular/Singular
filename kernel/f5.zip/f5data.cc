//! \file f5data.h
/****************************************
*  Computer Algebra System SINGULAR     *
****************************************/
/* $Id: f5data.cc,v 1.9 2009/03/04 20:23:05 ederc Exp $ */
/*
* ABSTRACT: lpolynomial definition 
*/
#include "mod2.h"

#ifdef HAVE_F5
#include "kutil.h"
#include "structs.h"
#include "omalloc.h"
#include "polys.h"
#include "p_polys.h"
#include "ideals.h"
#include "febase.h"
#include "kstd1.h"
#include "khstd.h"
#include "kbuckets.h"
#include "weight.h"
#include "intvec.h"
#include "pInline1.h"
#include "f5gb.h"
#include "f5data.h"
#include "f5lists.h"
/*
=====================
everything is inlined 
=====================
*/
#endif
